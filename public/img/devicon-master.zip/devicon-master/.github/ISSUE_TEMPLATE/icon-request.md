---
name: Icon Request
about: Requesting a new icon or changes to an existing icon
title: 'Icon request: [NAME]'
labels: 'request:icon'
assignees: ''

---

### About the icon
*Short description of why you think this icon belongs in our project.*

### Links
*Provide links to the icon's official website/repository. Anywhere that shows us what the technology is about and its official logo. If available, also provide some resources (SVG's) where the icon can be found (Font Awesome, Icomoon, etc..).*
