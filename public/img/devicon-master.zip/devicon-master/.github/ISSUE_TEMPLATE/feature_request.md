---
name: Feature Request
about: Requesting a new feature or changes to an existing feature
title: 'Feature Request: [NAME]'
labels: 'enhancement'
assignees: ''

---

### Problem 
*Tell us about the current problem that you face that this feature might help you with.*

### Suggested Feature
*Short description of the feature.*

### Why we should have this feature
*List any extra benefits, other than solving your problem, that this feature will bring to the repo. If none, leave blank.*
