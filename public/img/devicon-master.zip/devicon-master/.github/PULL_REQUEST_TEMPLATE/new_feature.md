---
name: New Feature
about: Add a new feature to the repository.
title: 'New Feature: [NAME]'
labels: 'enhancement'
assignees: ''

---

## This PR adds...

*List your features here and the benefits they bring.*

## Notes

*List anything note-worthy here (potential issues, this needs to be merged to `master` before working, etc....).*
*Don't forget to link any issues that this PR will solved.*
